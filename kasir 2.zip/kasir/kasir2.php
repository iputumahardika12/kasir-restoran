<?php
session_start();
include 'header.html';


?>
<center><h2>Program Kasir</h2></center>
<br/>
<h3>Menu Minuman</h3>
<ol>
<li>Teh Anget/ Dingin</li>
<li>Kopi</li>
<li>Jus jeruk </li>
<li>Jus advokat</li>
</ol>
<br/>
<form method="POST">
<table>
<tr>
<td>Pilih Menu Minuman Nomer: </td>
<td><input type="text" name="minuman" size="15" /></td>
</tr>
<tr>
<td>Banyak Porsi : </td>
<td><input type="text" name="porsi" size="15" /></td>
</tr>
<tr>
<td><input type="submit" name="proses" value="Proses" /></td>
</tr>
</table>
</form>

<?php
if(isset($_POST['proses'])){
$NoMinuman = isset($_POST['minuman'])? $_POST['minuman']:NULL;
$porsi = isset($_POST['porsi'])? $_POST['porsi']:NULL;

if(empty($NoMinuman) || empty($porsi)){
include 'footer.html';
echo "<script>alert('Maaf, Cek kembali pilihan minuman Anda ! ');</script>";
return;

}

if($NoMinuman == 1){
$hargaMinum = '3000';
$totalMinum = $hargaMinum*$porsi;
$minum = 'teh';



}else if($NoMinuman == 2){
$hargaMinum= '4000';
$totalMinum = $hargaMinum*$porsi;
$minum = 'kopi';


}else if($NoMinuman == 3){
$hargaMinum = '8000';
$totalMinum = $hargaMinum*$porsi;
$minum = 'Jus jeruk';


}else if($NoMinuman == 4){
$hargaMinum = '10000';
$totalMinum = $hargaMinum*$porsi;
$minum = 'Jus Advokat';


}else{
include 'footer.html';
echo "<script>alert('Maaf, Cek kembali pilihan minuman Anda ! ');</script>";
return;
}

$_SESSION['totalMinum'] = $totalMinum;
$_SESSION['minum'] = $minum;
$_SESSION['hargaMinum'] = $hargaMinum;
$_SESSION['porsiMinum'] = $porsi;

echo"<script>document.location='kasir3.php'</script>";


}


?>



<?php
include 'footer.html';
?>