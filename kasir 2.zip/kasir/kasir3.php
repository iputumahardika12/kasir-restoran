<?php
session_start();
include 'header.html';
?>
<center><h2>Program Kasir</h2></center>
<?php

$totalmakan = $_SESSION['totalMakan'];
$totalminum = $_SESSION['totalMinum'];
$makan = $_SESSION['makan'];
$minum = $_SESSION['minum'];
$porsiMakan = $_SESSION['porsiMakan'];
$porsiMinum = $_SESSION['porsiMinum'];
$total = $totalmakan + $totalminum;

echo '<h4>Total semuanya = Rp. ' . $total . "</h4>";
?>


<form method='post'>
<table>
<tr>
<td>Bayar: </td>
<td><input type='text'size='15' name ='bayar' /></td>
<td><input type='submit' name='proses' value='Proses' /></td>
</tr>
</table>
</form>

<?php
if (isset($_POST['proses'])) {
$bayar = isset($_POST['bayar']) ? $_POST['bayar'] : NULL;

$kembalian = $bayar - $total;

if ($bayar < $total) {
echo '<h3>Maaf, Uang anda tidak cukup ' . $kembalian . '</h3>';
include'footer.html';
return;
}
echo '<h2> Rincian </h2>';
echo '~ Makanan: '.$makan.' x '.$porsiMakan.' = Rp. '.$totalmakan.'<br/>';
echo '~ Minuman: '.$minum.' x '.$porsiMinum.' = Rp. '.$totalminum.'<br/>';
echo '~ Total = Rp. '.$total.'<br/><br/>';
echo 'Bayar = Rp. '.$bayar.'<br/>';
echo 'Kembalian = Rp. '.$kembalian.'<br/>';
echo '<center><h4>Terimakasih</h4></center><br/>';
echo '<center><a href="kasirUtama.php">Klik untuk kembali ke menu utama !</a></center>';

}
?>
<?php
include 'footer.html';
?>