<?php
session_start();

include 'header.html';
?>
<center><h2>Program Kasir</h2></center>
<br/>
<h3>Menu Makanan</h3>
<ol>
<li>Nasi Padang + Ayam</li>
<li>Nasi Padang + Telur</li>
<li>Nasi Padang + Ikan</li>
</ol>
<br/>
<form method="POST">
<table>
<tr>
<td>Pilih Menu Makanan Nomer: </td>
<td><input type="text" name="makanan" size="15" /></td>
</tr>
<tr>
<td>Banyak Porsi : </td>
<td><input type="text" name="porsi" size="15" /></td>
</tr>
<tr>
<td><input type="submit" name="proses" value="Proses" /></td>
</tr>
</table>
</form>

<?php
if(isset($_POST['proses'])){
$NoMakanan = isset($_POST['makanan'])? $_POST['makanan']:NULL;
$porsi = isset($_POST['porsi'])? $_POST['porsi']:NULL;

if(empty($NoMakanan) || empty($porsi)){
include 'footer.html';
echo "<script>alert('Maaf, Cek kembali pilihan makanan Anda ! ');</script>";
return;

}

if($NoMakanan == 1){
$hargaMakan = '12000';
$totalMakan = $hargaMakan*$porsi;
$makan = 'Nasi Ayam';


}else if($NoMakanan == 2){
$hargaMakan = '8000';
$totalMakan = $hargaMakan*$porsi;
$makan = 'Nasi Telur';



}else if($NoMakanan == 3){
$hargaMakan = '10000';
$totalMakan = $hargaMakan*$porsi;
$makan = 'Nasi Ikan';

}else{
include 'footer.html';
echo "<script>alert('Maaf, Cek kembali pilihan makanan Anda ! ');</script>";
return;
}
$_SESSION['makan'] = $makan;
$_SESSION['totalMakan'] = $totalMakan;
$_SESSION['hargaMakan'] = $hargaMakan;
$_SESSION['porsiMakan'] = $porsi;

echo"<script>document.location='kasir2.php'</script>";
}
?>

<?php
include 'footer.html';
?>